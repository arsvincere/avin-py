# ============================================================================
# URL:          http://avin.info
# AUTHOR:       Alex Avin
# E-MAIL:       mr.alexavin@gmail.com
# LICENSE:      MIT
# ============================================================================

"""Custom exceptions."""


class ConfigNotFound(Exception): ...


class DataNotFound(Exception): ...


class InvalidToken(Exception): ...


class TickerNotFound(Exception): ...
